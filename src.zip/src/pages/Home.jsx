import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function Home() {
  const [groups, setGroups] = useState([]);

  useEffect(() => {
    fetch("http://localhost:4000/groups")
      .then((res) => res.json())
      .then(setGroups)
      .catch(console.error);
  }, []);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">All Groups</h1>

      {groups.length === 0 ? (
        <p>No groups available.</p>
      ) : (
        <ul className="space-y-2">
          {groups.map((group) => (
            <li key={group.id}>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>{group.name}</CardTitle>
                  <Link to={`/group/${group.id}/summary`}>
                    <Button>View Summary</Button>
                  </Link>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{group.members.length} Members</p>
                </CardContent>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
