import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function GroupSummary() {
  const { groupId } = useParams();
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [paidById, setPaidById] = useState("");
  const [message, setMessage] = useState("");

  const fetchSummary = () => {
    fetch(`http://localhost:4000/groups/${groupId}/summary`)
      .then((res) => res.json())
      .then((data) => {
        setSummary(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchSummary();
  }, [groupId]);

  const handleExpenseSubmit = async (e) => {
    e.preventDefault();
    setMessage("Adding...");

    try {
      const res = await fetch(
        `http://localhost:4000/groups/${groupId}/expenses`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            description,
            amount: parseFloat(amount),
            paidById: parseInt(paidById),
          }),
        }
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Something went wrong");
      }

      setMessage("Expense added successfully!");
      setDescription("");
      setAmount("");
      setPaidById("");
      fetchSummary(); // Refresh summary after adding
    } catch (err) {
      setMessage(err.message);
    }
  };

  if (loading) return <div className="p-4">Loading summary...</div>;
  if (!summary) return <div className="p-4">Error loading group summary.</div>;

  return (
    <div className="p-4 space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{summary.group}</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Total Expense: ₹{summary.totalExpense}</p>
          <p>Split Per Head: ₹{summary.splitPerHead}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Members</CardTitle>
        </CardHeader>
        <CardContent>
          <ul>
            {summary.members.map((member) => (
              <li key={member.id}>
                {member.name} — Paid: ₹{member.paid}, Owes: ₹{member.owes}, Balance: ₹
                {member.balance}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {summary.transactions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <ul>
              {summary.transactions.map((tx, idx) => (
                <li key={idx}>
                  {tx.from} → {tx.to}: ₹{tx.amount}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Add New Expense</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleExpenseSubmit} className="space-y-4">
            <Input
              type="text"
              placeholder="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />

            <Input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />

            <Select onValueChange={setPaidById} value={paidById}>
              <SelectTrigger>
                <SelectValue placeholder="Paid By" />
              </SelectTrigger>
              <SelectContent>
                {summary.members.map((member) => (
                  <SelectItem key={member.id} value={member.id.toString()}>
                    {member.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button type="submit">Add Expense</Button>

            {message && <div>{message}</div>}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
