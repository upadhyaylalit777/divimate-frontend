
import './App.css';
import CreateGroup from './pages/CreateGroup';
import Createuser from './pages/Createuser';
import GroupSummary from "./pages/GroupSummary";
import Home from "./pages/Home";
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Layout from './Components/Layout';
import { Toaster } from 'sonner';
import TestForm from './pages/testform';


function App() {
  return (
    <div className="App">

    <BrowserRouter>
    <Layout>
      
      <Routes>
        
        <Route path="/" element={<Home />} />
        <Route path="/create-user" element={<Createuser />} />
        <Route path="/create-group" element={<CreateGroup />} />
        <Route path="/group/:groupId/summary" element={<GroupSummary />} />
        <Route path="/test-form" element={<TestForm/>} />
      </Routes>
      
      </Layout>
    </BrowserRouter>
    </div>
  );
}

export default App;
