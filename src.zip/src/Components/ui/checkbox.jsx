// This is a placeholder for the Checkbox component
export function Checkbox() {
  return (
    <input type="checkbox" />
  )
}
