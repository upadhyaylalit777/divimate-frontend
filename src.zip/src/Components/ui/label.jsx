// This is a placeholder for the Label component
export function Label() {
  return (
    <label>Label</label>
  )
}
