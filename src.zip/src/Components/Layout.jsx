import { Link } from "react-router-dom";

export default function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-blue-600 text-white p-4 flex justify-between">
        <Link to="/" className="font-bold">DiviMate</Link>
        <nav className="space-x-4">
          <Link to="/create-user" className="hover:underline">Create User</Link>
          <Link to="/create-group" className="hover:underline">Create Group</Link>
        </nav>
      </header>

      <main className="flex-grow p-4 max-w-3xl mx-auto">
        {children}
      </main>

      <footer className="bg-blue-600 text-white text-center p-4">
        © 2025 DiviMate App
      </footer>
    </div>
  );
}
